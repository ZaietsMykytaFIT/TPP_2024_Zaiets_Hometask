#pragma once

namespace CppCLRWinFormsProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Data::OleDb;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::GroupBox^ groupBox1;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::MenuStrip^ menuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^ actionsToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ placeHolderToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ aboutToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ exitToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ exitToolStripMenuItem1;
	private: System::Windows::Forms::ToolStripMenuItem^ exitToolStripMenuItem2;
	private: System::Windows::Forms::ToolStripMenuItem^ aboutAuthorToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ exitToolStripMenuItem3;
	private: System::Windows::Forms::ToolStripMenuItem^ exitToolStripMenuItem4;
	private: System::Windows::Forms::ToolStripMenuItem^ aboutAppToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ holderOfThePlaceToolStripMenuItem;
	private: System::Windows::Forms::DataGridView^ dataGridView1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ ID;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ PlanetName;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ PlanetSize;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ DistanceTo;
	private: System::Windows::Forms::DataGridViewCheckBoxColumn^ HasLife;








































	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->actionsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->placeHolderToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->holderOfThePlaceToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->aboutToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->aboutAuthorToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->aboutAppToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->exitToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->exitToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->exitToolStripMenuItem2 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->exitToolStripMenuItem3 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->exitToolStripMenuItem4 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->ID = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->PlanetName = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->PlanetSize = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->DistanceTo = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->HasLife = (gcnew System::Windows::Forms::DataGridViewCheckBoxColumn());
			this->groupBox1->SuspendLayout();
			this->menuStrip1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->button2);
			this->groupBox1->Controls->Add(this->button1);
			this->groupBox1->Controls->Add(this->button4);
			this->groupBox1->Controls->Add(this->button3);
			this->groupBox1->Location = System::Drawing::Point(446, 39);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(160, 352);
			this->groupBox1->TabIndex = 0;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"Actions";
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(29, 280);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(112, 48);
			this->button2->TabIndex = 1;
			this->button2->Text = L"Remove";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(29, 40);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(112, 48);
			this->button1->TabIndex = 0;
			this->button1->Text = L"Add";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(29, 200);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(112, 48);
			this->button4->TabIndex = 1;
			this->button4->Text = L"Load";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click);
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(29, 120);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(112, 48);
			this->button3->TabIndex = 2;
			this->button3->Text = L"Update";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// menuStrip1
			// 
			this->menuStrip1->GripMargin = System::Windows::Forms::Padding(2, 2, 0, 2);
			this->menuStrip1->GripStyle = System::Windows::Forms::ToolStripGripStyle::Visible;
			this->menuStrip1->ImageScalingSize = System::Drawing::Size(24, 24);
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {
				this->actionsToolStripMenuItem,
					this->aboutToolStripMenuItem, this->exitToolStripMenuItem
			});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(618, 33);
			this->menuStrip1->TabIndex = 1;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// actionsToolStripMenuItem
			// 
			this->actionsToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {
				this->placeHolderToolStripMenuItem,
					this->holderOfThePlaceToolStripMenuItem
			});
			this->actionsToolStripMenuItem->Name = L"actionsToolStripMenuItem";
			this->actionsToolStripMenuItem->Size = System::Drawing::Size(87, 29);
			this->actionsToolStripMenuItem->Text = L"Actions";
			// 
			// placeHolderToolStripMenuItem
			// 
			this->placeHolderToolStripMenuItem->Name = L"placeHolderToolStripMenuItem";
			this->placeHolderToolStripMenuItem->Size = System::Drawing::Size(256, 34);
			this->placeHolderToolStripMenuItem->Text = L"PlaceHolder";
			// 
			// holderOfThePlaceToolStripMenuItem
			// 
			this->holderOfThePlaceToolStripMenuItem->Name = L"holderOfThePlaceToolStripMenuItem";
			this->holderOfThePlaceToolStripMenuItem->Size = System::Drawing::Size(256, 34);
			this->holderOfThePlaceToolStripMenuItem->Text = L"HolderOfThePlace";
			// 
			// aboutToolStripMenuItem
			// 
			this->aboutToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {
				this->aboutAuthorToolStripMenuItem,
					this->aboutAppToolStripMenuItem
			});
			this->aboutToolStripMenuItem->Name = L"aboutToolStripMenuItem";
			this->aboutToolStripMenuItem->Size = System::Drawing::Size(78, 29);
			this->aboutToolStripMenuItem->Text = L"About";
			// 
			// aboutAuthorToolStripMenuItem
			// 
			this->aboutAuthorToolStripMenuItem->Name = L"aboutAuthorToolStripMenuItem";
			this->aboutAuthorToolStripMenuItem->Size = System::Drawing::Size(224, 34);
			this->aboutAuthorToolStripMenuItem->Text = L"About Author";
			// 
			// aboutAppToolStripMenuItem
			// 
			this->aboutAppToolStripMenuItem->Name = L"aboutAppToolStripMenuItem";
			this->aboutAppToolStripMenuItem->Size = System::Drawing::Size(224, 34);
			this->aboutAppToolStripMenuItem->Text = L"About App";
			// 
			// exitToolStripMenuItem
			// 
			this->exitToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->exitToolStripMenuItem1 });
			this->exitToolStripMenuItem->Name = L"exitToolStripMenuItem";
			this->exitToolStripMenuItem->Size = System::Drawing::Size(55, 29);
			this->exitToolStripMenuItem->Text = L"Exit";
			// 
			// exitToolStripMenuItem1
			// 
			this->exitToolStripMenuItem1->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->exitToolStripMenuItem2 });
			this->exitToolStripMenuItem1->Name = L"exitToolStripMenuItem1";
			this->exitToolStripMenuItem1->Size = System::Drawing::Size(141, 34);
			this->exitToolStripMenuItem1->Text = L"Exit";
			// 
			// exitToolStripMenuItem2
			// 
			this->exitToolStripMenuItem2->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->exitToolStripMenuItem3 });
			this->exitToolStripMenuItem2->Name = L"exitToolStripMenuItem2";
			this->exitToolStripMenuItem2->Size = System::Drawing::Size(141, 34);
			this->exitToolStripMenuItem2->Text = L"Exit";
			// 
			// exitToolStripMenuItem3
			// 
			this->exitToolStripMenuItem3->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->exitToolStripMenuItem4 });
			this->exitToolStripMenuItem3->Name = L"exitToolStripMenuItem3";
			this->exitToolStripMenuItem3->Size = System::Drawing::Size(141, 34);
			this->exitToolStripMenuItem3->Text = L"Exit";
			// 
			// exitToolStripMenuItem4
			// 
			this->exitToolStripMenuItem4->Name = L"exitToolStripMenuItem4";
			this->exitToolStripMenuItem4->Size = System::Drawing::Size(141, 34);
			this->exitToolStripMenuItem4->Text = L"Exit";
			this->exitToolStripMenuItem4->Click += gcnew System::EventHandler(this, &Form1::exitToolStripMenuItem4_Click);
			// 
			// dataGridView1
			// 
			this->dataGridView1->AllowUserToOrderColumns = true;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(5) {
				this->ID, this->PlanetName,
					this->PlanetSize, this->DistanceTo, this->HasLife
			});
			this->dataGridView1->Location = System::Drawing::Point(12, 39);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->RowHeadersWidth = 12;
			this->dataGridView1->RowTemplate->Height = 28;
			this->dataGridView1->Size = System::Drawing::Size(428, 373);
			this->dataGridView1->TabIndex = 2;
			// 
			// ID
			// 
			this->ID->AutoSizeMode = System::Windows::Forms::DataGridViewAutoSizeColumnMode::AllCellsExceptHeader;
			this->ID->FillWeight = 1;
			this->ID->HeaderText = L"ID";
			this->ID->MinimumWidth = 34;
			this->ID->Name = L"ID";
			this->ID->Width = 34;
			// 
			// PlanetName
			// 
			this->PlanetName->AutoSizeMode = System::Windows::Forms::DataGridViewAutoSizeColumnMode::AllCells;
			this->PlanetName->HeaderText = L"PlanetName";
			this->PlanetName->MinimumWidth = 8;
			this->PlanetName->Name = L"PlanetName";
			this->PlanetName->Width = 155;
			// 
			// PlanetSize
			// 
			this->PlanetSize->AutoSizeMode = System::Windows::Forms::DataGridViewAutoSizeColumnMode::AllCells;
			this->PlanetSize->FillWeight = 90;
			this->PlanetSize->HeaderText = L"PlanetSize";
			this->PlanetSize->MinimumWidth = 64;
			this->PlanetSize->Name = L"PlanetSize";
			this->PlanetSize->Width = 142;
			// 
			// DistanceTo
			// 
			this->DistanceTo->AutoSizeMode = System::Windows::Forms::DataGridViewAutoSizeColumnMode::AllCells;
			this->DistanceTo->FillWeight = 95;
			this->DistanceTo->HeaderText = L"DistanceTo";
			this->DistanceTo->MinimumWidth = 64;
			this->DistanceTo->Name = L"DistanceTo";
			this->DistanceTo->Width = 148;
			// 
			// HasLife
			// 
			this->HasLife->AutoSizeMode = System::Windows::Forms::DataGridViewAutoSizeColumnMode::ColumnHeader;
			this->HasLife->FillWeight = 1;
			this->HasLife->HeaderText = L"Life";
			this->HasLife->MinimumWidth = 34;
			this->HasLife->Name = L"HasLife";
			this->HasLife->Width = 49;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(12, 25);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(618, 424);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->menuStrip1);
			this->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->MainMenuStrip = this->menuStrip1;
			this->Margin = System::Windows::Forms::Padding(4);
			this->Name = L"Form1";
			this->Text = L"Planetary";
			this->groupBox1->ResumeLayout(false);
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void exitToolStripMenuItem4_Click(System::Object^ sender, System::EventArgs^ e)
	{
		Application::Exit();
	}

	private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e)
	{
		String^ connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DB_PLANETS.accdb";
		OleDbConnection^ dbConnection = gcnew OleDbConnection(connectionString);

		dbConnection->Open();
		String^ query = "SELECT * FROM [TablePlanet]";
		OleDbCommand^ dbCommand = gcnew OleDbCommand(query, dbConnection);
		OleDbDataReader^ dbReader = dbCommand->ExecuteReader();

		if (dbReader->HasRows == false) {
			MessageBox::Show("No data", "Error");
		}
		else {
			while (dbReader->Read())
				dataGridView1->Rows->Add(dbReader["ID"], dbReader["PlanetName"], dbReader["PlanetSize"], dbReader["DistanceTo"], dbReader["PlanetSize"]);

		}
		dbReader->Close();
		dbConnection->Close();
	}

	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e)
	{
		if (dataGridView1->SelectedRows->Count != 1)
		{
			MessageBox::Show("Choose row", "Pay attention");
			return;
		}
		int index = dataGridView1->SelectedRows[0]->Index;
		if (dataGridView1->Rows[index]->Cells[0]->Value == nullptr ||
			dataGridView1->Rows[index]->Cells[1]->Value == nullptr ||
			dataGridView1->Rows[index]->Cells[2]->Value == nullptr ||
			dataGridView1->Rows[index]->Cells[3]->Value == nullptr) {
			MessageBox::Show("Not all data filled", "Pay attention");
			return;
		}
		String^ id = dataGridView1->Rows[index]->Cells[0]->Value->ToString();
		String^ name = dataGridView1->Rows[index]->Cells[1]->Value->ToString();
		String^ size = dataGridView1->Rows[index]->Cells[2]->Value->ToString();
		String^ distance = dataGridView1->Rows[index]->Cells[3]->Value->ToString();
		bool life = Convert::ToBoolean(dataGridView1->Rows[index]->Cells[4]->Value);

		String^ connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DB_PLANETS.accdb";
		OleDbConnection^ dbConnection = gcnew OleDbConnection(connectionString);
		dbConnection->Open();
		String^ query = "INSERT INTO [TablePlanet] VALUES (" + id + ", '" + name + "', '" + size + "', " + distance + ", " + (life ? "1" : "0") + ")";
		OleDbCommand^ dbCommand = gcnew OleDbCommand(query, dbConnection);

		if (dbCommand->ExecuteNonQuery() != 1)
			MessageBox::Show("������� � ���������", "�������");
		else
			MessageBox::Show("���� ������", "��");
		dbConnection->Close();
	}

	private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e)
	{
		if (dataGridView1->SelectedRows->Count != 1)
		{
			MessageBox::Show("������� ������ ���� �����", "�������� �����");
			return;
		}
		int index = dataGridView1->SelectedRows[0]->Index;
		if (dataGridView1->Rows[index]->Cells[0]->Value == nullptr ||
			dataGridView1->Rows[index]->Cells[1]->Value == nullptr ||
			dataGridView1->Rows[index]->Cells[2]->Value == nullptr ||
			dataGridView1->Rows[index]->Cells[3]->Value == nullptr) {
			MessageBox::Show("�� �� ���� �", "�������� �����");
			return;
		}
		String^ id = dataGridView1->Rows[index]->Cells[0]->Value->ToString();
		String^ name = dataGridView1->Rows[index]->Cells[1]->Value->ToString();
		String^ size = dataGridView1->Rows[index]->Cells[2]->Value->ToString();
		String^ distance = dataGridView1->Rows[index]->Cells[3]->Value->ToString();
		bool life = Convert::ToBoolean(dataGridView1->Rows[index]->Cells[4]->Value);

		String^ connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DB_PLANETS.accdb";
		OleDbConnection^ dbConnection = gcnew OleDbConnection(connectionString);
		try {
			dbConnection->Open();

			// Specify the column names explicitly
			String^ query = "INSERT INTO [TablePlanet] ([ID], [PlanetName], [PlanetSize], [DistanceTo], [Life]) VALUES (?, ?, ?, ?, ?)";
			OleDbCommand^ dbCommand = gcnew OleDbCommand(query, dbConnection);

			// Use parameterized query to add values
			dbCommand->Parameters->AddWithValue("?", id);
			dbCommand->Parameters->AddWithValue("?", name);
			dbCommand->Parameters->AddWithValue("?", size);
			dbCommand->Parameters->AddWithValue("?", distance);
			dbCommand->Parameters->AddWithValue("?", life ? 1 : 0);

			// Execute the insert command
			if (dbCommand->ExecuteNonQuery() != 1) {
				MessageBox::Show("Issue in running", "Error");
			}
			else {
				MessageBox::Show("Data added", "Ok");
			}
		}
		catch (Exception^ ex) {
			MessageBox::Show("Database error: " + ex->Message, "Error");
		}
		finally {
			dbConnection->Close();
		}
	}

	private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e)
	{
		if (dataGridView1->SelectedRows->Count != 1) {
			MessageBox::Show("������� ������ ���� �����", "�������� �����");
			return;
		}

		int index = dataGridView1->SelectedRows[0]->Index;

		// Check if all required cell values are present
		if (dataGridView1->Rows[index]->Cells[0]->Value == nullptr ||
			dataGridView1->Rows[index]->Cells[1]->Value == nullptr ||
			dataGridView1->Rows[index]->Cells[2]->Value == nullptr ||
			dataGridView1->Rows[index]->Cells[3]->Value == nullptr ||
			dataGridView1->Rows[index]->Cells[4]->Value == nullptr) {
			MessageBox::Show("�� �� ���� �", "�������� �����");
			return;
		}

		// Retrieve the id from the selected row
		String^ id = dataGridView1->Rows[index]->Cells[0]->Value->ToString();

		// Define connection string using ACE provider for better compatibility
		String^ connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DB_PLANETS.accdb";
		OleDbConnection^ dbConnection = gcnew OleDbConnection(connectionString);

		try {
			dbConnection->Open();

			// Use a parameterized query to safely pass the id value
			String^ query = "DELETE FROM [TablePlanet] WHERE ID = ?";
			OleDbCommand^ dbCommand = gcnew OleDbCommand(query, dbConnection);
			dbCommand->Parameters->AddWithValue("?", id);

			// Execute the delete command
			if (dbCommand->ExecuteNonQuery() != 1) {
				MessageBox::Show("������� � ���������", "�������");
			}
			else {
				MessageBox::Show("���� ��������", "��");
				dataGridView1->Rows->RemoveAt(index);
			}
		}
		catch (Exception^ ex) {
			MessageBox::Show("������� �� ��� ������ � ����� �����: " + ex->Message, "�������");
		}
		finally {
			dbConnection->Close();
		}
	}
	};
}